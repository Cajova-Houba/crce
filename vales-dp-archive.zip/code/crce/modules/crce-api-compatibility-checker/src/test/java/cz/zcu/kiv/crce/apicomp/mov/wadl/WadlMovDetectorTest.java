package cz.zcu.kiv.crce.apicomp.mov.wadl;

public class WadlMovDetectorTest {
}
