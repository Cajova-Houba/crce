package cz.zcu.kiv.crce.apicomp.result;

/**
 * Interface containing keys to the additional info map of compatibility check result.
 */
public interface AdditionalInfoKeys {

    String MOV_FLAG = "MOV";
}
