package cz.zcu.kiv.crce.apicomp.impl.webservice.common.xsd;

public class XsdDataType {
    public final String name;
    public final int order;

    public XsdDataType(String name, int order) {
        this.name = name;
        this.order = order;
    }
}
