package cz.zcu.kiv.crce.resolver;

/**
 * Date: 11.4.16
 *
 * @author Jakub Danek
 */
public enum Operator {
    AND,
    OR;
}
