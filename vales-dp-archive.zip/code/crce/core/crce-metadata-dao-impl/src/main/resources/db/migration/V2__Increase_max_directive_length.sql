ALTER TABLE capability_directive ALTER COLUMN value VARCHAR(4096) NOT NULL;

ALTER TABLE requirement_directive ALTER COLUMN value VARCHAR(4096) NOT NULL;
