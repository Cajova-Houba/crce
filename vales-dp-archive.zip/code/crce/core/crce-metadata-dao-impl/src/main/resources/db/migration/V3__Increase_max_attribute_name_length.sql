ALTER TABLE capability_attribute ALTER COLUMN name VARCHAR(32) NOT NULL;

ALTER TABLE requirement_attribute ALTER COLUMN name VARCHAR(32) NOT NULL;

ALTER TABLE resource_property_attribute ALTER COLUMN name VARCHAR(32) NOT NULL;

ALTER TABLE capability_property_attribute ALTER COLUMN name VARCHAR(32) NOT NULL;
