package cz.zcu.kiv.crce.webui.internal.custom;

import cz.zcu.kiv.crce.webui.internal.legacy.Capability;
import cz.zcu.kiv.crce.webui.internal.legacy.Requirement;

public class RequirementAdapter implements Requirement {

    @Override
    public String getName() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getFilter() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isMultiple() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isOptional() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isExtend() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public String getComment() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isWritable() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isSatisfied(Capability capability) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public Requirement setFilter(String filter) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Requirement setMultiple(boolean multiple) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Requirement setOptional(boolean optional) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Requirement setExtend(boolean extend) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Requirement setComment(String comment) {
        // TODO Auto-generated method stub
        return null;
    }
}
